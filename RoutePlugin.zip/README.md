# RoutePlugin

Ein Spigot/Paper-Plugin, um Routen ähnlich wie in Google Maps zu erstellen und mit Partikeln sichtbar zu machen.

## Features
- `/route create <Name>` erstellt eine neue Route.
- `/route setparticle <RouteName> <Particle>` setzt den Partikeltyp.
- `/route follow start <RouteName>` startet die Routenverfolgung.
- `/route follow pause|unpause|end` steuert die Verfolgung.
- `/route edit select <RouteName>` wählt eine Route zum Bearbeiten.
- `/route edit linefollowstart|pause|unpause|deselect` erstellt Punkte automatisch beim Bewegen.
- `/route edit point add` fügt manuell einen Punkt hinzu.
- Fortschrittsmeldungen alle 50 Punkte.
- Zufälliges Feuerwerk + Sound beim Abschluss.

## Installation
1. Mit Maven bauen:
   ```
   mvn clean package
   ```
2. JAR nach `plugins/` kopieren.
3. Server starten.
